'use client';
import { FormEvent, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ArrowLeft, ArrowRight, Eye, EyeOff, LockKeyhole, Route, ShieldCheck, Truck, Boxes, UserCog } from 'lucide-react';
import { isSupabaseConfigured, supabase } from '@/lib/supabase';

type Role = 'business' | 'owner' | 'admin';
export default function LoginPage() {
  const router = useRouter();
  const [mode,setMode] = useState<'login'|'signup'>('login');
  const [role,setRole] = useState<Role>('business');
  const [name,setName] = useState('');
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const [showPassword,setShowPassword] = useState(false);
  const [loading,setLoading] = useState(false);
  const [message,setMessage] = useState('');
  const [error,setError] = useState('');

  useEffect(() => { if (!isSupabaseConfigured) return; supabase.auth.getSession().then(({data}) => { if (data.session) router.replace('/dashboard'); }); },[router]);

  async function submit(e: FormEvent) {
    e.preventDefault(); setError(''); setMessage(''); setLoading(true);
    try {
      if (!isSupabaseConfigured) throw new Error('Connect Supabase first: add NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY in Vercel → Settings → Environment Variables, then redeploy.');
      if (mode === 'signup') {
        if (!name.trim()) throw new Error('Please enter your full name or business name.');
        const {data,error} = await supabase.auth.signUp({ email: email.trim(), password, options: { data: { full_name: name.trim(), role } } });
        if (error) throw error;
        if (data.session) router.replace('/dashboard');
        else setMessage('Account created. Check your email to confirm your account, then sign in. If you want instant prototype access, disable email confirmation in Supabase Auth settings.');
      } else {
        const {error} = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        router.replace('/dashboard'); router.refresh();
      }
    } catch (e: any) { setError(e?.message || 'Something went wrong. Please try again.'); }
    finally { setLoading(false); }
  }
  return <main className="auth-layout"><aside className="auth-aside"><Link href="/" className="brand brand-white"><span className="brand-mark"><Route size={21}/></span><span>empty<span className="brand-light">return</span><small>LOGISTICS EXCHANGE</small></span></Link><div className="auth-pitch"><div className="eyebrow eyebrow-light">FREIGHT, MADE SMARTER</div><h1>Every return<br/>trip has <span>potential.</span></h1><p>One secure workspace to match spare truck capacity with real business demand.</p><div className="auth-benefits"><span><ShieldCheck size={17}/> Verification-first profiles</span><span><Truck size={17}/> Return-trip capacity listings</span><span><Boxes size={17}/> Business-to-business bookings</span></div></div><div className="aside-bottom">A smarter way to move what matters.</div></aside><section className="auth-main"><Link href="/" className="back-link"><ArrowLeft size={16}/> Back to home</Link><div className="auth-card"><div className="mobile-brand"><span className="brand-mark"><Route size={20}/></span><b>emptyreturn</b></div><div className="auth-heading"><div className="section-kicker">YOUR LOGISTICS WORKSPACE</div><h2>{mode === 'login' ? 'Welcome back' : 'Create your account'}</h2><p>{mode === 'login' ? 'Sign in to manage your trips, shipments and bookings.' : 'Choose your role to set up the right workspace.'}</p></div>
      <div className="auth-tabs"><button className={mode==='login'?'active':''} onClick={()=>{setMode('login');setError('');setMessage('');}}>Sign in</button><button className={mode==='signup'?'active':''} onClick={()=>{setMode('signup');setError('');setMessage('');}}>Create account</button></div>
      {mode==='signup' && <div className="role-picker"><button type="button" className={role==='business'?'role-option selected':''} onClick={()=>setRole('business')}><Boxes size={19}/><span><b>Business / SME</b><small>Ship goods</small></span></button><button type="button" className={role==='owner'?'role-option selected':''} onClick={()=>setRole('owner')}><Truck size={19}/><span><b>Truck operator</b><small>List capacity</small></span></button></div>}
      <form onSubmit={submit} className="auth-form">{mode==='signup' && <label>Full name or business name<input value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Agra Textiles" autoComplete="name" required/></label>}<label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@company.com" autoComplete="email" required/></label><label>Password<div className="password-wrap"><input type={showPassword?'text':'password'} value={password} onChange={e=>setPassword(e.target.value)} placeholder={mode==='signup'?'At least 8 characters':'Enter your password'} autoComplete={mode==='signup'?'new-password':'current-password'} minLength={6} required/><button type="button" className="eye-btn" onClick={()=>setShowPassword(!showPassword)} aria-label="Toggle password visibility">{showPassword?<EyeOff size={17}/>:<Eye size={17}/>}</button></div></label>
      {error && <div className="alert alert-error">{error}</div>}{message && <div className="alert alert-success">{message}</div>}
      <button className="btn btn-primary auth-submit" disabled={loading}>{loading?'Please wait…':mode==='login'?'Sign in securely':'Create account'} <ArrowRight size={17}/></button></form>
      <div className="auth-footnote"><LockKeyhole size={14}/> Secure authentication powered by Supabase</div>
      {!isSupabaseConfigured && <div className="setup-hint"><b>One-time setup required</b><p>This deployment needs your Supabase project URL and anon key in Vercel Environment Variables. No localhost redirect is used; the app redirects on the current deployed domain.</p></div>}
      <p className="switch-mode">{mode==='login'?"New to EmptyReturn?":"Already have an account?"} <button onClick={()=>{setMode(mode==='login'?'signup':'login');setError('');setMessage('');}}>{mode==='login'?'Create an account':'Sign in'}</button></p>
      <p className="admin-note"><UserCog size={14}/> Admin access is assigned securely in the database, not by public sign-up.</p>
    </div></section></main>;
}
