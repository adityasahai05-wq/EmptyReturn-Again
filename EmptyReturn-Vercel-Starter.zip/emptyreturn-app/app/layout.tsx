import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'EmptyReturn — Freight, made smarter',
  description: 'Connect spare return-trip truck capacity with SME shipment demand.',
  applicationName: 'EmptyReturn'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
