-- EmptyReturn MVP schema for Supabase Postgres.
-- Run in Supabase Dashboard -> SQL Editor. This script is designed for a new project.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'business' check (role in ('business','owner','admin')),
  phone text,
  company_name text,
  gstin text,
  verification_status text not null default 'pending' check (verification_status in ('pending','verified','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.trips (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  origin text not null,
  destination text not null,
  departure_at timestamptz not null,
  available_weight_kg numeric(12,2) not null check (available_weight_kg > 0),
  available_volume_m3 numeric(12,2) not null default 0 check (available_volume_m3 >= 0),
  price numeric(12,2) not null check (price >= 0),
  vehicle_type text not null,
  vehicle_number text not null,
  status text not null default 'available' check (status in ('available','booked','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.shipments (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.profiles(id) on delete cascade,
  origin text not null,
  destination text not null,
  goods_description text not null,
  weight_kg numeric(12,2) not null check (weight_kg > 0),
  budget numeric(12,2) not null check (budget >= 0),
  pickup_date timestamptz not null,
  status text not null default 'open' check (status in ('open','matched','booked','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id) on delete restrict,
  shipment_id uuid not null references public.shipments(id) on delete restrict,
  business_id uuid not null references public.profiles(id) on delete restrict,
  owner_id uuid not null references public.profiles(id) on delete restrict,
  agreed_price numeric(12,2) not null check (agreed_price >= 0),
  status text not null default 'requested' check (status in ('requested','confirmed','in_transit','delivered','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);

create table if not exists public.vehicle_locations (
  booking_id uuid primary key references public.bookings(id) on delete cascade,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  latitude double precision not null check (latitude between -90 and 90),
  longitude double precision not null check (longitude between -180 and 180),
  accuracy_m double precision,
  updated_at timestamptz not null default now()
);

create index if not exists trips_status_departure_idx on public.trips(status, departure_at);
create index if not exists shipments_status_pickup_idx on public.shipments(status, pickup_date);
create index if not exists bookings_business_idx on public.bookings(business_id, created_at desc);
create index if not exists bookings_owner_idx on public.bookings(owner_id, created_at desc);
create index if not exists messages_booking_created_idx on public.messages(booking_id, created_at);

-- Create profile after signup. Public signup cannot grant itself admin permissions.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
declare requested_role text;
begin
  requested_role := coalesce(new.raw_user_meta_data->>'role', 'business');
  if requested_role not in ('business','owner') then requested_role := 'business'; end if;
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), requested_role)
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin'); $$;

alter table public.profiles enable row level security;
alter table public.trips enable row level security;
alter table public.shipments enable row level security;
alter table public.bookings enable row level security;
alter table public.messages enable row level security;
alter table public.vehicle_locations enable row level security;

-- Profiles: users may see themselves; other participants can see basic profiles. Admin can review all.
drop policy if exists "profile select self admin" on public.profiles;
create policy "profile select self admin" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_admin());
drop policy if exists "profile update self" on public.profiles;
create policy "profile update self" on public.profiles for update to authenticated
using (id = auth.uid() and role <> 'admin') with check (id = auth.uid() and role <> 'admin');
-- Prevent a user changing their own role by column update: grant only non-privileged columns.
revoke update on public.profiles from authenticated;
grant update (full_name, phone, company_name, gstin) on public.profiles to authenticated;

-- Authenticated users can browse capacity and shipments; owners manage their own listings; admins moderate.
drop policy if exists "trips browse" on public.trips;
create policy "trips browse" on public.trips for select to authenticated using (true);
drop policy if exists "owner create trip" on public.trips;
create policy "owner create trip" on public.trips for insert to authenticated
with check (owner_id = auth.uid() and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'owner'));
drop policy if exists "owner update trip" on public.trips;
create policy "owner update trip" on public.trips for update to authenticated
using (owner_id = auth.uid() or public.is_admin()) with check (owner_id = auth.uid() or public.is_admin());
drop policy if exists "owner delete trip" on public.trips;
create policy "owner delete trip" on public.trips for delete to authenticated using (owner_id = auth.uid() or public.is_admin());

drop policy if exists "shipments browse" on public.shipments;
create policy "shipments browse" on public.shipments for select to authenticated using (true);
drop policy if exists "business create shipment" on public.shipments;
create policy "business create shipment" on public.shipments for insert to authenticated
with check (business_id = auth.uid() and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'business'));
drop policy if exists "business update shipment" on public.shipments;
create policy "business update shipment" on public.shipments for update to authenticated
using (business_id = auth.uid() or public.is_admin()) with check (business_id = auth.uid() or public.is_admin());

drop policy if exists "booking participant select" on public.bookings;
create policy "booking participant select" on public.bookings for select to authenticated
using (business_id = auth.uid() or owner_id = auth.uid() or public.is_admin());
drop policy if exists "business create booking" on public.bookings;
create policy "business create booking" on public.bookings for insert to authenticated
with check (business_id = auth.uid() and exists (select 1 from public.shipments s where s.id = shipment_id and s.business_id = auth.uid()) and exists (select 1 from public.trips t where t.id = trip_id and t.owner_id = owner_id));
drop policy if exists "booking participants update" on public.bookings;
create policy "booking participants update" on public.bookings for update to authenticated
using (business_id = auth.uid() or owner_id = auth.uid() or public.is_admin())
with check (business_id = auth.uid() or owner_id = auth.uid() or public.is_admin());

drop policy if exists "booking participants read messages" on public.messages;
create policy "booking participants read messages" on public.messages for select to authenticated
using (exists (select 1 from public.bookings b where b.id = booking_id and (b.business_id = auth.uid() or b.owner_id = auth.uid() or public.is_admin())));
drop policy if exists "booking participants send messages" on public.messages;
create policy "booking participants send messages" on public.messages for insert to authenticated
with check (sender_id = auth.uid() and exists (select 1 from public.bookings b where b.id = booking_id and (b.business_id = auth.uid() or b.owner_id = auth.uid() or public.is_admin())));

drop policy if exists "booking participants read location" on public.vehicle_locations;
create policy "booking participants read location" on public.vehicle_locations for select to authenticated
using (exists (select 1 from public.bookings b where b.id = booking_id and (b.business_id = auth.uid() or b.owner_id = auth.uid() or public.is_admin())));
drop policy if exists "owner share location" on public.vehicle_locations;
create policy "owner share location" on public.vehicle_locations for insert to authenticated
with check (owner_id = auth.uid() and exists (select 1 from public.bookings b where b.id = booking_id and b.owner_id = auth.uid() and b.status in ('confirmed','in_transit')));
drop policy if exists "owner update location" on public.vehicle_locations;
create policy "owner update location" on public.vehicle_locations for update to authenticated
using (owner_id = auth.uid() or public.is_admin()) with check (owner_id = auth.uid() or public.is_admin());

-- Create the first admin manually after signing up: update public.profiles set role='admin' where id='AUTH_USER_UUID';
-- Do not add the service-role key to any NEXT_PUBLIC environment variable.
