# EmptyReturn — Logistics Exchange MVP

A responsive Next.js web prototype based on the EmptyReturn business proposal: connect SMEs needing part-load transport with truck operators who have spare capacity on a return journey.

## What is included

- Responsive landing page and role-based sign-up/sign-in (SME / business, truck operator).
- Supabase authentication and Postgres schema with Row Level Security policies.
- Dashboards for trips, shipment requests, bookings, profile and verification status.
- Return-trip and shipment creation forms; booking requests and status transitions.
- In-app messages tied to a booking.
- Google Maps JavaScript API integration and browser GPS sharing for an active booking.
- Demo preview data when Supabase isn't configured. Demo mode is for UI preview only and doesn't save real data or publish GPS.

## Important limits (read before launch)

This is an MVP starter, not a fully audited commercial logistics system. Real GPS updates require the truck operator to sign in, grant browser location permission, have an active confirmed/in-transit booking, and keep the tracking page open. Mobile browsers may pause location updates in the background; reliable background tracking generally requires a native mobile app. Google Maps needs a valid API key and billing-enabled Google Cloud project. Identity verification is represented by a status only; **this starter intentionally does not collect or store Aadhaar scans/numbers**. Do not launch commercial shipments until you add secure document upload/review, legal and insurance workflows, privacy/retention rules, rate limiting, monitoring, and payment settlement as required.

## Deploy directly to Vercel (no localhost redirect setup)

1. Create a GitHub repository and upload the contents of this folder (the files inside `emptyreturn-app`, not the folder zipped as a nested project).
2. In Vercel, choose **Add New → Project**, import that GitHub repository, and keep the framework as **Next.js**. Vercel will detect the build command automatically (`next build`).
3. Create a Supabase project. In Supabase **SQL Editor**, run the complete `supabase/schema.sql` file.
4. In Vercel → Project → **Settings → Environment Variables**, add:
   - `NEXT_PUBLIC_SUPABASE_URL` = your Supabase Project URL
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = your Supabase anon/public key
   - `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY` = your Google Maps JavaScript API key
   Add them for Production (and Preview if you need preview deployments), then redeploy.
5. In Supabase → **Authentication → URL Configuration**, set **Site URL** to your deployed Vercel URL, e.g. `https://your-project.vercel.app`. Add that same URL to **Redirect URLs**. This app uses the current origin / Supabase auth session and does not hard-code `localhost:3000`.
6. In Supabase → Authentication settings, email confirmation may be left enabled for real users. If testing with disposable accounts and you want immediate signup, you can disable confirmation temporarily; turn it back on for real use.
7. To create an administrator, first sign up normally, copy the user's UUID from Supabase Authentication → Users, then run this in SQL Editor: `update public.profiles set role = 'admin' where id = 'PASTE-USER-UUID-HERE';`. Public sign-up cannot assign admin role.
8. In Google Cloud Console, enable **Maps JavaScript API**, configure billing, and restrict the API key by website referrer to your Vercel domain. Never expose any private/server key.

## Local development (optional only)

`npm install` then `npm run dev`. Local development normally uses port 3000; that is separate from production sign-in. You do not need local development to deploy to Vercel. To avoid login redirect errors, the Supabase Site URL / Redirect URLs must match the deployed domain.

## Stack

- Next.js 14 + React + TypeScript
- Supabase Auth + PostgreSQL + Row Level Security
- Google Maps JavaScript API (optional until configured)
- Vercel deployment

## Current MVP caveats

- Route matching is a browse-and-request workflow, not an optimized dispatch engine.
- Pricing and demo routes are illustrative, not verified market quotes.
- Booking notifications are in-app UI only; email/SMS/push notifications need a provider.
- Tracking shows the truck operator's current browser location and is not a route replay/history product.
- Admin moderation is intentionally minimal; verification decisions should be made through a secure admin process.
